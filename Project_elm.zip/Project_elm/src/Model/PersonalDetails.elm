module Model.PersonalDetails exposing (..)

import Html exposing (..)
import Html.Attributes exposing (class, id, href)

type alias DetailWithName =
    { name : String
    , detail : String
    }

type alias PersonalDetails =
    { name : String
    , contacts : List DetailWithName
    , intro : String
    , socials : List DetailWithName
    }

view : PersonalDetails -> Html msg
view details =
-- div [] []
    div [][
        h1 [id "name"][text details.name]
        , em [id "intro"][text details.intro]
        , h3 [class "contact-detail"][text "gabor_vlad@gmail.com"]
        , h3 []
            [ a
                [href "https://github.com/GaborVlad", class "social-link"]
                [text "Github"]
            ]
    ]
